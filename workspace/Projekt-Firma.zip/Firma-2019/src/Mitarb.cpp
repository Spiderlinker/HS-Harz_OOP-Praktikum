//------------------------------------------------------------------------------
// Datei: Mitarb.cpp
//
// Implementierung der Klasse zur Verwaltung eines Mitarbeiters
//
// Autoren:
// Version 1.0: 24.11.2019
// -----------------------------------------------------------------------------
