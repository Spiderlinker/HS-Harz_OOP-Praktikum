//------------------------------------------------------------------------------
// Datei: Abteil.cpp
//
// Implementierung der Klasse zur Verwaltung der Mitarbeiter einer Abteilung
//
// Autoren:
// Version 1.0: 24.11.2019
// -----------------------------------------------------------------------------
